#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include<string.h>
#include<sys/wait.h>

#include <stdlib.h>
#include <string.h>

#include <fcntl.h>

#include <sys/stat.h>
#include<termios.h>
#include "parse.h"
#include "execute.h"
#include "split.h"
void execute(char **, int, char **);

int parse(char *, char **, char **, int *);

char **split(char *,char *);
#define INPUT_STRING_SIZE 80

#define NORMAL 				00
#define OUTPUT_REDIRECTION 	11
#define INPUT_REDIRECTION 	22
#define BACKGROUND			44
#define OUTPUT_APP	55
int top=0;
typedef struct proc
{
	int id;
	char process[1024];//stores mapping of process and process id
}proc;

int no=0;
proc pro[1024];
proc jobs[1024];
typedef void (*sighandler_t)(int);
char * home;
int cd(char **args)//cd command
{

	if(!args[1])//check for no argument in cd
	{

		chdir(home);
		return 1;

	}
	int i=0;
	char dir[1024];
	strcpy(dir,args[1]);
	for(i=0;dir[i]!='\0';i++) //check for ~ in cd command
		if(dir[i]=='~' && i>0)
			perror("error");
	if(dir[0]=='~')
	{
		char temp1[1024];
		char temp2[1024];
		int j=1;
		int m=0;
		for(;dir[j]!='\0';j++,m++)
			temp1[m]=dir[j];
		int k=m;
		j=0;
		for(;home[j]!='\0';j++)
		{
			temp2[j]=home[j];
		}
		int l=0;
		for(l=0;l<k;l++)
		{
			temp2[j]=temp1[l];
			j++;
		}
		temp2[j]='\0';
		strcpy(dir,temp2);
	}
	strcpy(args[1],dir);
	if(args[1][0]!='\0')
	{
		if(chdir(args[1])!=0)
		{
			perror("error");
		}
	}
	return 1;
}
int echo(char **args,int argc) //echo command
{


	if (argc > 1)
	{

		int j;
		for(j=0;args[1][j]!='\0';j++)
		{
			if(args[1][j]!='"')
				printf("%c",args[1][j]);

		}
		printf(" ");
	}
	int i;
	for (i = 2; i < argc; i++)
	{
		int j;
		for(j=0;args[i][j]!='\0';j++)
		{
			if(args[i][j]!='"')
				printf("%c",args[i][j]);

		}
		printf(" ");
	}

	printf("\n");
	return 1;
}
int  pwd()//pwd command
{	char cwd[1024];
	getcwd(cwd,sizeof(cwd));
	printf("%s\n",cwd);
	return 1;
}

int main(int argc, char *argv[])
{
	int status=1;
	int i, mode = NORMAL, cmdArgc;
	size_t len = INPUT_STRING_SIZE;
	char *cpt, *inputString, *cmdArgv[INPUT_STRING_SIZE], *supplement = NULL;
	inputString = (char*)malloc(sizeof(char)*INPUT_STRING_SIZE);
	char curDir[100];
	home = (char *)malloc(100*sizeof(char));
	getcwd(home,100);
char hostname[1024];
gethostname(hostname,sizeof(hostname));
char *username;
                username=getenv("USER");

	while(1)
	{int status1;
		pid_t t;
		mode = NORMAL;
		getcwd(curDir, 100);
		proc temp3[1024];
		proc temp4[1024];
		

				int c=0;
				int m=0;


				for(c=0;c<no;c++)
				{
					pid_t pid_result = waitpid(pro[c].id, &status, WNOHANG);

					if(kill(pro[c].id,0)==-1 && errno==ESRCH){
						printf("Process %s  exited whose id is %d\n",pro[c].process,pro[c].id);
						printf("YES");
					}
					else
					{	
						temp3[m]=pro[c];
						temp4[m]=jobs[c];
						m++;
					}
				}
				no=m;
				for(c=0;c<no;c++)
				{
					pro[c]=temp3[c];
					jobs[c]=temp4[c];
				}
		int len1=strlen(home);
		int totallen=strlen(curDir);
		int ii;
		int flag=0;
		char path[100];
		for(ii=0;ii<len1;ii++)
			if(curDir[ii]!=home[ii])
				flag=1;
		if(flag==0)
		{

			for(ii=len1;ii<=totallen;ii++)
				path[ii-len1+1]=curDir[ii];
			path[0]='~';



		}
		else
		{
			for(ii=0;ii<totallen;ii++)
				path[ii]=curDir[ii];


		}	
		printf("%s@%s:%s$",username,hostname,path);
		getline( &inputString, &len, stdin);
		if(strcmp(inputString, "exit\n") == 0)
			exit(0);
		char **args2;
		args2=split(inputString,";");
		for(i=0;args2[i]!=NULL;i++)
		{

			cmdArgc = parse(args2[i], cmdArgv, &supplement, &mode);

			if(strcmp(*cmdArgv, "cd") == 0)
			{
				cd(cmdArgv);
			}
			else if(strcmp(*cmdArgv, "") == 0)
			{
				continue;
			}

			else if(strcmp(*cmdArgv, "pwd") == 0)
			{
				pwd();
			}

			else if(strcmp(*cmdArgv, "echo") == 0)
			{
				echo(cmdArgv,cmdArgc);
			}
			else if(strcmp("pinfo",*cmdArgv)==0)
			{
				FILE *fp;
				char buf1[256],buf2[256];
				int pid;
				char name[256],state;
				long unsigned int size;
				if(cmdArgc==1)
				{
					sprintf(buf1,"/proc/%d/stat",getpid());					//open the stat and exe files
					sprintf(buf2,"/proc/%d/exe",getpid());
				}
				else
				{
					sprintf(buf1,"/proc/%s/stat",(cmdArgv[1]));
					sprintf(buf2,"/proc/%s/exe",(cmdArgv[1]));
				}
				if((fp=fopen(buf1,"r"))!=NULL)
				{
					/*scan the stat file*/
					fscanf(fp,"%d %*s %c %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %lu %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d",&pid,&state,&size);												
					fclose(fp);									
					printf("pid -- %d\nProcess Status -- %c\nmemory -- %lu\n",pid,state,size);
					readlink(buf2,name,256);
					printf("Executable Path -- %s\n",name);
				}
				else
					perror("No such process");

			}


			else 
				execute(cmdArgv, mode, &supplement);
		}
	}

	return 0;
}


