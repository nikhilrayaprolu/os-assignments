#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include<string.h>
#include<sys/wait.h>
#define INPUT_STRING_SIZE 80

#define NORMAL 				00
#define OUTPUT_REDIRECTION 	11
#define INPUT_REDIRECTION 	22
#define BACKGROUND			44
#define OUTPUT_APP	55
extern int top;
typedef struct proc
{
	int id;
	char process[1024];//stores mapping of process and process id
}proc;

extern int no;
extern proc pro[1024];
extern proc jobs[1024];
typedef void (*sighandler_t)(int);
extern char * home;

void execute(char **cmdArgv, int mode, char **supplementPtr)
	{
		pid_t pid, pid2;
		FILE *fp;
		int mode2 = NORMAL, cmdArgc, status1, status2;
		char *cmdArgv2[INPUT_STRING_SIZE], *supplement2 = NULL;
		pid = fork();
		if( pid < 0)
		{
			printf("Error occured");
			exit(-1);
		}
		else if(pid == 0)
		{
			

			if(mode == BACKGROUND)
			{
				
				setpgid(getpid(),getpid()); 
				sigset_t emptyset;
				sigemptyset(&emptyset);
				signal (SIGINT, SIG_DFL);
				signal (SIGQUIT, SIG_DFL);
				signal (SIGTSTP, SIG_DFL);
				signal (SIGTTIN, SIG_DFL);
				signal (SIGTTOU, SIG_DFL);
				signal (SIGCHLD, SIG_DFL);
				//the process is not brought to the foreground s it is a background process
			}
			if (execvp(cmdArgv[0], cmdArgv) == -1)
			{
				perror("error");
			}

		}
		else
		{
			if(mode == BACKGROUND)
			{
				setpgid(pid,pid);
				pro[no].id=(int)pid;
				jobs[no].id=(int)pid;
				strcpy(jobs[no].process,"\0");
				strcpy(pro[no].process,cmdArgv[0]);
				int j=0;
				printf("[%d]\n",pid);


				for(;cmdArgv[j]!=NULL;j++)
				{	
					strcat(jobs[no].process,cmdArgv[j]);
					strcat(jobs[no].process," ");

				}
				no++;
			}

			else
				waitpid(pid, &status1, 0);
			//wait(NULL);
		}
	}
