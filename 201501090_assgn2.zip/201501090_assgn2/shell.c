#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include<string.h>
#include<sys/wait.h>
void execute(char **, int, char **);
void handle_signal(int);
int parse(char *, char **, char **, int *);
void chop(char *);
char **split(char *,char *);
#define INPUT_STRING_SIZE 80

#define NORMAL 				00
#define OUTPUT_REDIRECTION 	11
#define INPUT_REDIRECTION 	22
#define BACKGROUND			44
#define OUTPUT_APP	55
int top=0;
typedef struct proc
{
	int id;
	char process[1024];//stores mapping of process and process id
}proc;

int no=0;
proc pro[1024];
proc jobs[1024];
typedef void (*sighandler_t)(int);
char * home;
int cd(char **args)//cd command
{

	if(!args[1])//check for no argument in cd
	{

		chdir(home);
		return 1;

	}
	int i=0;
	char dir[1024];
	strcpy(dir,args[1]);
	for(i=0;dir[i]!='\0';i++) //check for ~ in cd command
		if(dir[i]=='~' && i>0)
			perror("error");
	if(dir[0]=='~')
	{
		char temp1[1024];
		char temp2[1024];
		int j=1;
		int m=0;
		for(;dir[j]!='\0';j++,m++)
			temp1[m]=dir[j];
		int k=m;
		j=0;
		for(;home[j]!='\0';j++)
		{
			temp2[j]=home[j];
		}
		int l=0;
		for(l=0;l<k;l++)
		{
			temp2[j]=temp1[l];
			j++;
		}
		temp2[j]='\0';
		strcpy(dir,temp2);
	}
	strcpy(args[1],dir);
	if(args[1][0]!='\0')
	{
		if(chdir(args[1])!=0)
		{
			perror("error");
		}
	}
	return 1;
}
int echo(char **args,int argc) //echo command
{


	if (argc > 1)
	{

		int j;
		for(j=0;args[1][j]!='\0';j++)
		{
			if(args[1][j]!='"')
				printf("%c",args[1][j]);

		}
		printf(" ");
	}
	int i;
	for (i = 2; i < argc; i++)
	{
		int j;
		for(j=0;args[i][j]!='\0';j++)
		{
			if(args[i][j]!='"')
				printf("%c",args[i][j]);

		}
		printf(" ");
	}

	printf("\n");
	return 1;
}
int  pwd()//pwd command
{	char cwd[1024];
	getcwd(cwd,sizeof(cwd));
	printf("%s\n",cwd);
	return 1;
}

int main(int argc, char *argv[])
{
	int i, mode = NORMAL, cmdArgc;
	size_t len = INPUT_STRING_SIZE;
	char *cpt, *inputString, *cmdArgv[INPUT_STRING_SIZE], *supplement = NULL;
	inputString = (char*)malloc(sizeof(char)*INPUT_STRING_SIZE);
	char curDir[100];
	home = (char *)malloc(100*sizeof(char));
	getcwd(home,100);
	while(1)
	{

		mode = NORMAL;
		getcwd(curDir, 100);
		proc temp3[1024];
		proc temp4[1024];
		//	while((t=waitpid(-1,&status1,WNOHANG))>0)//check for background processes status
		//	{

		//			if(WIFEXITED(status1)==0)
		//			{
		int c=0;
		int m=0;
		//		printf("arbads");

		for(c=0;c<no;c++)
		{
			//	pid_t pid_result = waitpid(pro[c].id, &status, WNOHANG);

			if(kill(pro[c].id,0)==-1 && errno==ESRCH)
				printf("Process %s  exited whose id is %d\n",pro[c].process,pro[c].id);
			else
			{	
				temp3[m]=pro[c];
				temp4[m]=jobs[c];
				m++;
			}
		}
		no=m;
		for(c=0;c<no;c++)
		{
			pro[c]=temp3[c];
			jobs[c]=temp4[c];
		}

		//	}
		printf("%s@%s->", getlogin(),curDir);
		getline( &inputString, &len, stdin);
		if(strcmp(inputString, "exit\n") == 0)
			exit(0);
		char **args2;
		args2=split(inputString,";");
		for(i=0;args2[i]!=NULL;i++)
		{
			printf("%c %d\n",args2[i][0],i);
			cmdArgc = parse(args2[i], cmdArgv, &supplement, &mode);
			printf("%syes%s %d\n",cmdArgv[0],cmdArgv[1],cmdArgc);
			if(strcmp(*cmdArgv, "cd") == 0)
			{printf("YES");
				cd(cmdArgv);
			}

			else if(strcmp(*cmdArgv, "pwd") == 0)
			{
				pwd();
			}

			else if(strcmp(*cmdArgv, "echo") == 0)
			{
				echo(cmdArgv,cmdArgc);
			}
			else if(strcmp("pinfo",*cmdArgv)==0)
			{
				FILE *fp;
				char buf1[256],buf2[256];
				int pid;
				char name[256],state;
				long unsigned int size;
				if(cmdArgc==1)
				{
					sprintf(buf1,"/proc/%d/stat",getpid());					//open the stat and exe files
					sprintf(buf2,"/proc/%d/exe",getpid());
				}
				else
				{
					sprintf(buf1,"/proc/%s/stat",(cmdArgv[1]));
					sprintf(buf2,"/proc/%s/exe",(cmdArgv[1]));
				}
				if((fp=fopen(buf1,"r"))!=NULL)
				{
					/*scan the stat file*/
					fscanf(fp,"%d %*s %c %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %lu %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d %*d",&pid,&state,&size);												
					fclose(fp);									
					printf("pid -- %d\nProcess Status -- %c\nmemory -- %lu\n",pid,state,size);
					readlink(buf2,name,256);
					printf("Executable Path -- %s\n",name);
				}
				else
					perror("No such process");

			}


			else 
				execute(cmdArgv, mode, &supplement);
		}
	}

	return 0;
	}
	char **split(char *line,char *delim)//split using delimiters
	{
		char * newline=(char*)malloc((1024)*sizeof(char));
		strcpy(newline,line);
		int size = 20,i = 0;
		char **tokens = malloc(size * sizeof(char*));
		char *token;
		if (!tokens) 
		{
			fprintf(stderr, "allocation error\n");
			exit(EXIT_FAILURE);
		}
		token = strtok(newline, delim);
		while (token != NULL) 
		{
			tokens[i] = token;
			i++;
			if (i >= size) 
			{
				size+=20;
				tokens = realloc(tokens,size * sizeof(char*));
				if (!tokens) 
				{
					fprintf(stderr, "allocation error\n");
					exit(EXIT_FAILURE);
				}
			}

			token = strtok(NULL, delim);
		}
		tokens[i] = NULL;
		return tokens;
	}

	int parse(char *inputString, char *cmdArgv[], char **supplementPtr, int *modePtr)
	{
		int cmdArgc = 0, terminate = 0;
		char *srcPtr = inputString;
		//printf("parse fun%sends", inputString);
		while(*srcPtr != '\0' && terminate == 0)
		{
			if(*srcPtr!=' ' && *srcPtr!='&'){ 
			
			*cmdArgv = srcPtr;
			//printf("parse fun2%sends", *cmdArgv);
			cmdArgc++;
			cmdArgv++;

			}
			while(*srcPtr != ' ' && *srcPtr != '\t' && *srcPtr != '\0' && *srcPtr != '\n' && terminate == 0)
			{
			
				switch(*srcPtr)
				{
					case '&':
						*modePtr = BACKGROUND;
						break;
				}
				srcPtr++;
			}
			while((*srcPtr == ' ' || *srcPtr == '\t' || *srcPtr == '\n') && terminate == 0)
			{
				*srcPtr = '\0';
				srcPtr++;
			}
		}
		/*srcPtr++;
		 *srcPtr = '\0';
		 destPtr--;*/
		*cmdArgv = '\0';
		return cmdArgc;
	}

	void chop(char *srcPtr)
	{
		while(*srcPtr != ' ' && *srcPtr != '\t' && *srcPtr != '\n')
		{
			srcPtr++;
		}
		*srcPtr = '\0';
	}
	/*void addtojob(pid_t pid)
	  {
	  int i;
	  for(i=0;i<MAX;i++)
	  {
	  if(arr[i].pid==-1)
	  {
	  if(i>top){top=i;}
	  arr[i].pid= pid;
	  strcpy(arr[i].cmd,command);
	  break;
	  }
	  }
	  }*/
	void execute(char **cmdArgv, int mode, char **supplementPtr)
	{
		pid_t pid, pid2;
		FILE *fp;
		int mode2 = NORMAL, cmdArgc, status1, status2;
		char *cmdArgv2[INPUT_STRING_SIZE], *supplement2 = NULL;
		pid = fork();
		if( pid < 0)
		{
			printf("Error occured");
			exit(-1);
		}
		else if(pid == 0)
		{
			printf("%d",mode);

			if(mode == BACKGROUND)
			{
				printf("YESits a background process");
				setpgid(getpid(),getpid()); 
				sigset_t emptyset;
				sigemptyset(&emptyset);
				signal (SIGINT, SIG_DFL);
				signal (SIGQUIT, SIG_DFL);
				signal (SIGTSTP, SIG_DFL);
				signal (SIGTTIN, SIG_DFL);
				signal (SIGTTOU, SIG_DFL);
				signal (SIGCHLD, SIG_DFL);
				//the process is not brought to the foreground s it is a background process
			}
			if (execvp(cmdArgv[0], cmdArgv) == -1)
			{
				perror("error");
			}

		}
		else
		{
			if(mode == BACKGROUND)
			{
				setpgid(pid,pid);
				pro[no].id=(int)pid;
				jobs[no].id=(int)pid;
				strcpy(jobs[no].process,"\0");
				strcpy(pro[no].process,cmdArgv[0]);
				int j=0;
				for(;cmdArgv[j]!=NULL;j++)
				{	
					strcat(jobs[no].process,cmdArgv[j]);
					strcat(jobs[no].process," ");

				}
				no++;
			}

			else
				waitpid(pid, &status1, 0);
			//wait(NULL);
		}
	}
