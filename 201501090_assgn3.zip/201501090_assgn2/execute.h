void execute(char **, int, char **,int);
