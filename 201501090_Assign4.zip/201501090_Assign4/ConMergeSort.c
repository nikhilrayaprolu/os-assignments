#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <limits.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
void mergeSort(int arr[], int l, int r);
void merge(int arr[], int l, int m, int r);
void sort(int * array, int l, int r);
void printArray(int A[], int size);
pid_t first_process_pid;

void mergeSort(int arr[], int l, int r)
{
	pid_t pid;
	int status,m;
	m = l+(r-l)/2;
	if (l-r <=5)
		sort(arr,l,r);
	if (l < r)
	{
		if((pid==fork()) < 0)
		{
			perror("fork error");
			exit(1);
		}
		if(pid == 0)
			mergeSort(arr, l, m);
		else
			mergeSort(arr, m+1, r);

	}

	if(pid!=0)
	{
		waitpid(pid,&status,0);
		merge(arr,l,m,r);
	}

	if(getpid() == first_process_pid )
		return ;
	else
		exit(0);
}

void merge(int arr[], int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 =  r - m;

	int L[n1], R[n2];

	for(i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for(j = 0; j < n2; j++)
		R[j] = arr[m + 1+ j];

	i = 0;
	j = 0;
	k = l;
	while (i < n1 && j < n2)
	{
		if (L[i] <= R[j])
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
		k++;
	}

	while (i < n1)
	{
		arr[k] = L[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		arr[k] = R[j];
		j++;
		k++;
	}
}
void sort(int * array, int l, int r)
{
	int i,position,j,swap ;

	for ( i=l ; i<=r-1 ; i++ )
	{
		position = i;

		for ( j=i+1 ; j<=r ; j++ )
		{
			if ( array[position] > array[j] )
				position = j;
		}
		if ( position != i )
		{
			swap = array[i];
			array[i] = array[position];
			array[position] = swap;
		}
	}

}


void printArray(int A[], int size)
{
	int i;
	for (i=0; i < size; i++)
		printf("%d \n", A[i]);
	printf("\n");
}

int main(void)
{
	int n, i;
	int *shm_array;
	int shm_id,length;
	key_t key;
	size_t shm_size;
	key = IPC_PRIVATE;

	printf("\n Enter the number of elements");
	scanf("%d",&length);
	int a[length];

	first_process_pid = getpid();
	printf("\n Enter the numbers for merge sort");
	for (i=0;i<length;i++)
		scanf("%d",&a[i]);

	shm_size = length * sizeof(int);
	if ((shm_id = shmget(key, shm_size, IPC_CREAT | 0666)) == -1) {
		perror("shmget");
		exit(1);
	}

	shm_array = shmat(shm_id, NULL, 0);

	for (i = 0; i < length; i++) {
		shm_array[i] = a[i];
	}

	printf("Given array is \n");
	printArray(shm_array, length);

	mergeSort(shm_array, 0, length - 1);

	printf("\nSorted array is \n");
	printArray(shm_array, length);

	return 0;
}

