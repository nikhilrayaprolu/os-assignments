#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#define MAX 100

int buffsize,fill=0,i;
sem_t mutex;
int buffer[MAX],use;
int threads =0;

typedef struct _rwlock_t
{
    sem_t lock;     
    sem_t writelock;
    int no_readers; 
    int write_flag;
} rwlock_t;

rwlock_t rw[MAX];
void *writer ()
{
    int i,fill=0;
    for(i=0;i<buffsize;i++)
    {
        sem_wait(&(rw[i].writelock));
        sem_wait(&(rw[i].lock));
            buffer[fill] = rand();
            rw[i].write_flag = 1;
            sleep(1);
            printf("\nvalue written is %d at %d location", buffer[fill],i);
            fill = (fill+1) % buffsize;
        sem_post(&(rw[i].lock));
        sem_post(&(rw[i].writelock));
    }
}

void *reader()
{
    int i,use=0;
    int id = ++threads;
    for(i=0;i<buffsize;i++)
    {
        sem_wait(&(rw[i].lock));

        if (rw[i].write_flag == 1)
        {
            rw[i].no_readers++;

            if (rw[i].no_readers == 1)
                sem_wait(&(rw[i].writelock));
            sleep(1);
            printf("\nvalue read is %d from %d location",buffer[use],i);
            use = (use + 1) % buffsize;
            if (rw[i].no_readers % buffsize == 0)
            {
                sem_post(&(rw[i].writelock)); 
                rw[i].write_flag = 0;
            }

        }
        sem_post(&(rw[i].lock));
    }
}


void rwlock_init(rwlock_t *rw)
{
    rw->no_readers = 0;
    sem_init(&rw->lock, 0, 1);
    sem_init(&rw->writelock, 0, 1);
    rw->no_readers =0 ;
    rw->write_flag =0;
}

int main(void)
{
    int n;
    time_t t;

    printf("enter the number of readers you want");
    scanf("%d",&n);

    buffsize = n;
    sem_init(&mutex, 0, 1);
    srand((unsigned) time(&t));

    int i;
    pthread_t rtid[n];
    pthread_t wtid;

    for(i=0;i<n;i++)
        rwlock_init(&rw[i]);

    pthread_create(&wtid,NULL,writer,NULL);

    for(i=0;i<n;i++)
        pthread_create(&rtid[i],NULL,reader,NULL);


    for(i=0;i<n;i++)
    pthread_join(rtid[i],NULL);

    pthread_join(wtid,NULL);

  return 0;
}
